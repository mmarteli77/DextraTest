package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class DextraTest {
	
	WebDriver driver = null;
	
	
	@Given("Dado que eu acesse a pagina da VV Test")
	public void dado_que_eu_acesse_a_pagina_da_vv_test() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:/eclipse/Marcelo_Workspace/CucumberJava/src/test/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver(); 
		driver.navigate().to("http://www.lourencodemonaco.com.br/vvtest/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
	    
	}

	@And("E acesse o menu Pesquisa  QA")
	public void e_acesse_o_menu_pesquisa_qa() {
		//System.out.println("E acesse o menu Pesquisa  QA");
		driver.findElement(By.id("menu-item-226")).click();
	    
	}

	@When("Quando eu preencher todos os campos obrigatorios")
	public void quando_eu_preencher_todos_os_campos_obrigatorios() {
		//System.out.println("Quando eu preencher todos os campos obrigatorios");
		driver.findElement(By.id("nf-field-5")).sendKeys("Marcelo");
		driver.findElement(By.id("nf-field-6")).sendKeys("Marteli Arruda");
		driver.findElement(By.id("nf-field-7")).sendKeys("martelimarteli@gmail.com");
		driver.findElement(By.id("nf-field-8")).sendKeys("martelimarteli@gmail.com");
		driver.findElement(By.id("nf-field-17")).sendKeys("991196732");
		driver.findElement(By.xpath("//*[@id=\"nf-label-class-field-10-1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"nf-field-11\"]/option[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"nf-field-12\"]/option[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"nf-label-class-field-13-1\"]")).click();
		driver.findElement(By.id("nf-field-14")).sendKeys("Java");
		driver.findElement(By.id("nf-field-15")).sendKeys("Gostaria de me aprofundar cada vez mais e mais nos testes automatizados");
	}

	@And("Clicar no botao enviar")
	public void clicar_no_botao_enviar() {
		//System.out.println("Clicar no botao enviar");
		driver.findElement(By.id("nf-field-16")).click();
	    
	}

	@Then("Entao deve ser direcionado para uma pagina de sucesso")
	public void ent_o_deve_ser_direcionado_para_uma_pagina_de_sucesso() throws InterruptedException {
		//System.out.println("Entao deve ser direcionado para uma pagina de sucesso");
		driver.getPageSource().contains("Pesquisa - QA");
		Thread.sleep(4000);
		
		driver.close();
		driver.quit();
		
	    
	}

}
